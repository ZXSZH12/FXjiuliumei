js = open('mt4.js', encoding='utf-8').read()
tpl = open('mt4.tpl.html', encoding='utf-8').read()
assert '<script>\n</script>' in tpl or '<script></script>' in tpl
out = tpl.replace('<script>\n</script>', '<script>\n' + js + '\n</script>')
open('fx-MT4.html', 'w', encoding='utf-8').write(out)
print('built fx-MT4.html', len(out))
