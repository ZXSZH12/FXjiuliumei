# -*- coding: utf-8 -*-
"""窗口管理回归测试：拖动钳制 / 最大化 / 置顶 / 对话框层级 / MT4 命名"""
import asyncio, sys
from playwright.async_api import async_playwright

from pathlib import Path
URL = Path(__file__).with_name("fx-MT4.html").resolve().as_uri()
fails = []

def check(name, cond, extra=""):
    print(("PASS " if cond else "FAIL ") + name + (("  " + str(extra)) if extra else ""))
    if not cond:
        fails.append(name)

async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch()
        pg = await b.new_page(viewport={"width": 1280, "height": 800})
        errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto(URL)
        await pg.wait_for_timeout(1200)
        await pg.click("#acctOk")          # 关掉启动账户对话框
        await pg.wait_for_timeout(2600)    # 等浏览器自动打开

        # 1) 无 JS 报错
        check("no page errors", not errs, errs[:3])

        # 2) MT4 命名（页面内不应再出现 MT4）
        body = await pg.evaluate("document.body.innerText")
        check("no MT5 text", "MT5" not in body)
        check("MT4 in start menu list", True)  # 打开开始菜单后检查
        await pg.click("#startBtn")
        await pg.wait_for_timeout(300)
        sm = await pg.evaluate("document.getElementById('startMenu').innerText")
        check("start menu shows MT4", "MT4" in sm, sm[:80].replace("\n", "|"))
        await pg.click("#smClose")

        # 2b) 浏览器刚打开时在主窗口上层
        z0 = await pg.evaluate("""() => ({
            app: getComputedStyle(document.getElementById('app')).zIndex,
            brw: getComputedStyle(document.getElementById('brw')).zIndex })""")
        check("browser above app on open", int(z0["brw"]) > int(z0["app"]), z0)

        # 3) 初始几何
        g0 = await pg.evaluate("""() => { const r = document.getElementById('app').getBoundingClientRect();
            return {l:r.left, t:r.top, w:r.width, h:r.height}; }""")
        check("app initial pos", abs(g0["l"] - 28) < 2 and abs(g0["t"] - 22) < 2, g0)

        # 4) 拖动主窗口（向右下拖 200,150）
        box = await pg.evaluate("""() => { const r = document.getElementById('tbar').getBoundingClientRect();
            return {x: r.left + r.width/2, y: r.top + 13}; }""")
        await pg.mouse.move(box["x"], box["y"])
        await pg.mouse.down()
        await pg.mouse.move(box["x"] + 200, box["y"] + 150, steps=10)
        await pg.mouse.up()
        g1 = await pg.evaluate("""() => { const r = document.getElementById('app').getBoundingClientRect();
            return {l:r.left, t:r.top, w:r.width, h:r.height}; }""")
        check("app dragged", abs(g1["l"] - (g0["l"] + 200)) < 3 and abs(g1["t"] - (g0["t"] + 150)) < 3, (g0, g1))
        check("app size kept while dragging", abs(g1["w"] - g0["w"]) < 3 and abs(g1["h"] - g0["h"]) < 3, (g0["w"], g1["w"]))

        # 5) 拖动钳制：往左上猛拖，标题栏不能完全消失
        await pg.mouse.move(box["x"] + 200, box["y"] + 150)
        await pg.mouse.down()
        await pg.mouse.move(-2000, -2000, steps=10)
        await pg.mouse.up()
        g2 = await pg.evaluate("""() => { const r = document.getElementById('app').getBoundingClientRect();
            return {l:r.left, t:r.top, w:r.width}; }""")
        check("app clamped top>=0", g2["t"] >= -1, g2)
        check("app clamped left keeps 100px", g2["l"] >= -(g2["w"] - 100) - 1, g2)

        # 6) 拖动钳制：往右下猛拖，标题栏不能进任务栏
        await pg.mouse.move(400, 20)
        await pg.mouse.down()
        await pg.mouse.move(5000, 5000, steps=10)
        await pg.mouse.up()
        g3 = await pg.evaluate("""() => { const r = document.getElementById('app').getBoundingClientRect();
            return {l:r.left, t:r.top, w:r.width}; }""")
        check("app clamped above taskbar", g3["t"] <= 800 - 42 - 12 + 1, g3)
        check("app clamped right keeps 100px", g3["l"] <= 1280 - 100 + 1, g3)

        # 7) 最大化 / 还原
        await pg.click("#btnMax")
        await pg.wait_for_timeout(300)
        g4 = await pg.evaluate("""() => { const r = document.getElementById('app').getBoundingClientRect();
            return {l:r.left, t:r.top, w:r.width, h:r.height, m: document.getElementById('app').classList.contains('maxed')}; }""")
        check("app maximized", g4["m"] and abs(g4["l"]) < 2 and abs(g4["t"]) < 2 and abs(g4["w"] - 1280) < 2 and abs(g4["h"] - (800 - 42)) < 2, g4)
        await pg.click("#btnMax")
        await pg.wait_for_timeout(300)
        g5 = await pg.evaluate("""() => { const r = document.getElementById('app').getBoundingClientRect();
            return {l:r.left, t:r.top, w:r.width, h:r.height}; }""")
        check("app unmaximized restores geo", abs(g5["l"] - g3["l"]) < 3 and abs(g5["t"] - g3["t"]) < 3 and abs(g5["w"] - g3["w"]) < 3, (g3, g5))

        # 8) 置顶：浏览器打开时在上层；点击主窗口后主窗口在上层
        # 先把主窗口最小化，避免它盖住浏览器导致点不到
        await pg.evaluate("""() => { const a = document.getElementById('app');
            a.style.left = '100px'; a.style.top = '60px'; }""")
        await pg.mouse.click(300, 73)   # 点主窗口标题栏 -> 主窗口置顶
        await pg.wait_for_timeout(200)
        z2 = await pg.evaluate("""() => ({
            app: getComputedStyle(document.getElementById('app')).zIndex,
            brw: getComputedStyle(document.getElementById('brw')).zIndex })""")
        check("click app raises it above browser", int(z2["app"]) > int(z2["brw"]), z2)
        # 最小化主窗口，点浏览器标题栏 -> 浏览器置顶
        await pg.click("#btnMin")
        await pg.wait_for_timeout(200)
        await pg.mouse.click(700, 90)
        await pg.wait_for_timeout(200)
        z3 = await pg.evaluate("""() => ({
            app: getComputedStyle(document.getElementById('app')).zIndex,
            brw: getComputedStyle(document.getElementById('brw')).zIndex })""")
        check("click browser raises it above app", int(z3["brw"]) > int(z3["app"]), z3)
        # 恢复主窗口
        await pg.click("#taskApp")
        await pg.wait_for_timeout(300)

        # 9) 任务栏永远在窗口之上
        ztb = await pg.evaluate("getComputedStyle(document.querySelector('.taskbar')).zIndex")
        check("taskbar above windows", int(ztb) > int(z3["brw"]) and int(ztb) > int(z3["app"]), (ztb, z3))

        # 10) 下单对话框盖过浏览器
        await pg.click("#btnNewOrder")
        await pg.wait_for_timeout(400)
        z4 = await pg.evaluate("""() => ({
            mask: getComputedStyle(document.getElementById('mask')).zIndex,
            brw: getComputedStyle(document.getElementById('brw')).zIndex,
            on: document.getElementById('mask').classList.contains('on') })""")
        check("order dlg above browser", z4["on"] and int(z4["mask"]) > int(z4["brw"]), z4)
        await pg.screenshot(path="shot_wm_dlg.png")
        await pg.keyboard.press("Escape")
        await pg.wait_for_timeout(200)

        # 11) 浏览器拖动 + 最大化（先最小化主窗口，避免遮挡）
        await pg.click("#btnMin")
        await pg.wait_for_timeout(200)
        await pg.evaluate("""() => { const b = document.getElementById('brw');
            b.style.left = '200px'; b.style.top = '100px'; }""")
        bb = await pg.evaluate("""() => { const r = document.getElementById('brwT').getBoundingClientRect();
            return {x: r.left + 100, y: r.top + 12}; }""")
        await pg.mouse.move(bb["x"], bb["y"])
        await pg.mouse.down()
        await pg.mouse.move(bb["x"] + 120, bb["y"] + 80, steps=8)
        await pg.mouse.up()
        gb = await pg.evaluate("""() => { const r = document.getElementById('brw').getBoundingClientRect();
            return {l:r.left, t:r.top}; }""")
        check("browser dragged", abs(gb["l"] - 320) < 3 and abs(gb["t"] - 180) < 3, gb)
        await pg.evaluate("document.getElementById('brwMax').click()")
        await pg.wait_for_timeout(300)
        gb2 = await pg.evaluate("""() => { const r = document.getElementById('brw').getBoundingClientRect();
            return {l:r.left, t:r.top, w:r.width, h:r.height}; }""")
        check("browser maximized", abs(gb2["l"]) < 2 and abs(gb2["w"] - 1280) < 2 and abs(gb2["h"] - 758) < 2, gb2)
        await pg.evaluate("document.getElementById('brwMax').click()")
        await pg.wait_for_timeout(300)
        gb3 = await pg.evaluate("""() => { const r = document.getElementById('brw').getBoundingClientRect();
            return {l:r.left, t:r.top}; }""")
        check("browser unmaximized restores", abs(gb3["l"] - 320) < 3 and abs(gb3["t"] - 180) < 3, gb3)

        # 12) 双击标题栏最大化（先恢复主窗口）
        await pg.click("#taskApp")
        await pg.wait_for_timeout(300)
        await pg.evaluate("""() => { const a = document.getElementById('app');
            a.style.left = '60px'; a.style.top = '40px'; }""")
        await pg.mouse.dblclick(300, 53)
        await pg.wait_for_timeout(300)
        mx = await pg.evaluate("document.getElementById('app').classList.contains('maxed')")
        check("dblclick titlebar maximizes", mx)
        await pg.mouse.dblclick(300, 13)
        await pg.wait_for_timeout(300)
        mx2 = await pg.evaluate("document.getElementById('app').classList.contains('maxed')")
        check("dblclick titlebar restores", not mx2)

        # 13) 截图：主窗口 + 浏览器重叠状态
        await pg.evaluate("""() => { const a = document.getElementById('app');
            a.style.left = '40px'; a.style.top = '30px'; a.style.width = '900px'; a.style.height = '560px'; }""")
        await pg.mouse.click(300, 43)
        await pg.wait_for_timeout(300)
        await pg.screenshot(path="shot_wm.png")

        await b.close()

asyncio.run(main())
print("\n==== %s ====" % ("ALL PASS" if not fails else "FAILURES: %s" % fails))
sys.exit(1 if fails else 0)
